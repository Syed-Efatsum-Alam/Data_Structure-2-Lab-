#include<iostream>
using namespace std;
void cakeCutting(int p[],int n)
{
    int r[n+1],sol[n+1];
    r[0]=0;
    for (int i=1 ; i<=n ; i++)
    {
        int q = -10000;
        for (int j=1 ; j<=i ; j++)
        {
            if(q<p[j]+r[i-j])
            {
                q = p[j]+r[i-j];
                sol[i]=j;
            }

        }
        r[i] = q;
    }
    cout<<"Inconme : "<<r[n]<<" taka\n";
    int curr_length = n;
    while(curr_length!=0)
    {
        cout<<sol[curr_length]<<" pieces togather "<<p[sol[curr_length]]<<" taka"<<endl;
        curr_length = curr_length-sol[curr_length];
    }
}
int main()
{
    int n;
    cout<<"Enter the number of slices: ";
    cin >> n;
    int slice[n+1];
    for (int i=1; i<=n; i++)
    {
        cin >> slice[i];
    }
    cakeCutting(slice,n);
    
    return 0;
}