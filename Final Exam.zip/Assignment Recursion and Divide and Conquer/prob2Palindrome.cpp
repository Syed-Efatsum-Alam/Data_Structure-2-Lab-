#include<iostream>
using namespace std;
int rev=0;
bool Check_palindrome(string s, int i, int j){
    if(i==j){
       
        return true;
    }
    if(s[i]!=s[j]){
        
        return false;
    }
    if(s[i]==s[j]){
        return true;
    }
    if(i<j+1){
        
        return Check_palindrome(s,i+1,j-1);
    }
}


bool is_palindrome(int n){
   string s=to_string(n);
   int x=s.length();
    if(n==0){
        return true;
    }
    return Check_palindrome(s,0,x-1);
   
}
void palindrome(int x,int y){
    if(x<y){
        if(is_palindrome(x)){
            cout<<x<<" ";
        }
        palindrome(x+1,y);

    }
    if(x==y){
        if(is_palindrome(x)){
            cout<<x<<" ";
        }
    }
    if(x>y){
        if(is_palindrome(y)){
            cout<<y<<" ";
        }
        palindrome(x,y+1);
        
    }
}
int sum_palindrom(int x,int y){
    if(x<y){
        if(is_palindrome(x)){
            return x+sum_palindrom(x+1,y);
        }
        else{
            return sum_palindrom(x+1,y);
        }
    }
    if(x==y){
        if(is_palindrome(x)){
            return x;
        }
        else{
            return 0;
        }
    }
    if(x>y){
        if(is_palindrome(y)){
            return y+sum_palindrom(x,y+1);
        }
        else{
            return sum_palindrom(x,y+1);
        }
    }
}

int main(){
    int x,y;
    cout<<"Enter the range: ";
    cin>>x>>y;
    palindrome(x,y);
    cout<<endl;
    int a= sum_palindrom(x,y);
    cout<<"sum "<<a<<endl;
    
    return 0;
}