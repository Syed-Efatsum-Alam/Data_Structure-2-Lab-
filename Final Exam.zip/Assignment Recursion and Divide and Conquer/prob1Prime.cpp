#include <iostream>
using namespace std;

int is_prime(int n)
{
    int i;
    if(n==1)
        return 0;
    for (i = 2; i < n; i++)
    {
        if (n % i == 0)
            return 0;
    }
    
    return 1;
}
int count_prime(int arr[],int size){
    if(size==0){
        return 0;
    }
    if(is_prime(arr[size-1])){
        return 1+count_prime(arr,size-1);
    }
    else{
        return count_prime(arr,size-1);
    }
        
}
void print_prime(int arr[],int size){
    if(size==0){
        return;
    }
    if(is_prime(arr[size-1])){
        cout<<arr[size-1]<<" ";
    }
    print_prime(arr,size-1);
}
void print_array(int arr[],int size){
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int n,arr[100];
    cout << "Enter Size of the array: ";
    cin >> n;
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    print_prime(arr,n);
    cout<<endl;
    cout << "#prime = " << count_prime(arr,n);
 
    return 0;
}
