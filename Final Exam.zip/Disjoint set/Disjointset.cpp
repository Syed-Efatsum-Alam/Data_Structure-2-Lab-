#include<bits/stdc++.h>
using namespace std;

/// Final task: implement path compression and union by rank
void make_set(int p[], int x,int rank[]){
    p[x] = x;
    rank[x] = 0;
    cout << "making a one-element set of "<<x<< endl;
}

int find_set(int p[], int x){
    if (x!=p[x])
        return find_set(p, p[x]);
    return p[x];
}

void _union(int p[], int x, int y,int rank[]){
    int a = find_set(p, x);
    int b = find_set(p, y);
    
    if(rank[a] > rank[b]){
        p[b] = a; 
    }
    else if(rank[a] < rank[b]){
        p[a] = b; 
    }
    else {
        p[a] = b;
        rank[b]++;
    }
    cout << "union "<<a << " and "<<b<< endl;
}


int main(){


    int N;
    cout << "Enter the Vertices" << endl;
    cin >> N;
    int p[N],rank[N];
    for (int i=0;i<N;i++){
        make_set(p, i,rank);
    }

     while(1){
        int option;
        cout << "Enter the option value you choose to see" << endl;
        cin >> option;


        /// if "option" is 1, take another integer x as input,
        /// check if x is an element of the disjoint set or not, and
        /// if it is then print the root/representative-element of x
        if (option==1){
            cout << "Enter an element to find its representative" << endl;
            int x;
            cin >> x;
            if(x>=0 && x<N)
                cout << find_set(p,x) << endl;
            else
                cout << "Not a valid element" << endl;

        }

        /// if "option" is 2, take integers x and y as input,
        /// check if x and y are elements of the disjoint set or not, and
        /// if they are check if they belong to the same set or not
        else if (option==2){
            int x,y;
            cout << "Enter two elements to check if they belong to the same set" << endl;
            cin >> x >> y;
            if(x>=0 && x<N && y>=0 && y<N){
                if(find_set(p,x) == find_set(p,y))
                    cout << "They belong to the same set" << endl;
                else
                    cout << "They belong to different sets" << endl;
            }
            else
                cout << "Not a valid element" << endl;

        }

        /// if "option" is 3, take integers x and y as input,
        /// check if x and y are elements of the disjoint set or not, and
        /// if they are then union them
        else if (option==3){
            int x,y;
            cout << "Enter two elements to union them" << endl;
            cin >> x >> y;
            if(x>=0 && x<N && y>=0 && y<N){
                _union(p,x,y,rank);
            }
            else
                cout << x<<"or"<<y<<"is not in the disjoint set" << endl;

        }

        else {
            break;
        }
    }
    return 0;
}
