#include<iostream>
using namespace std;

int power(int x,int y){
    if(y==0){
        return 1;
    }
    else{
       int mid=y/2;
       int a;
       if(y%2==0){
           a=power(x,mid);
           return a*a;
       }
       else{
           a=power(x,mid);
           return a*a*x;
       }
       
    }
}
int main() {
    int x,y;
    cout<<"enter the base"<<endl;
    cin>>x;
    cout<<"enter the power"<<endl;
    cin>>y;
    int ans=power(x,y);
    cout<<"the answer is "<<ans<<endl;
    return 0;
}