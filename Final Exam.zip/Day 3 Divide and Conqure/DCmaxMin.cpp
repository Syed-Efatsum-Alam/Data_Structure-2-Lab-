#include<iostream>
using namespace std;

struct Res{
    int max;
    int min;
};

Res MaxMin(int arr[],int start,int end){
    if(start==end){
        Res r;
        r.max=arr[start];
        r.min=arr[start];
        return r;
    }
    else{
        
        int mid=(start+end)/2;
        Res r1=MaxMin(arr,start,mid);
        Res r2=MaxMin(arr,mid+1,end);
        return {max(r1.max,r2.max),min(r1.min,r2.min)};       
    }
}

int main(int argc, char const *argv[])
{
    int arr[100],n;
    cout<<"enter the size of array"<<endl;
    cin>>n;
    cout<<"enter the elements of array"<<endl;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    Res r=MaxMin(arr,0,n-1);
    cout<<"the maximum element in the array is "<<r.max<<" the minimum element in the array is "<<r.min<< endl;
    return 0;
}
