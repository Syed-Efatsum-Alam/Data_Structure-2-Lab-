#include<iostream>
#include<algorithm>
using namespace std;

struct Employee
{
    string name;
    int id;
    int salary;
    
};
bool compare(Employee a, Employee b){   
     if (a.salary==b.salary) {
        return a.id<b.id;
     }
    return a.salary < b.salary; 

}
int main()
{
    int N;
    cout<<"Enter the number of Employee: "<<endl;
    cin>>N;
    struct Employee employee[N];
    for (int i=0;i<N;i++){
        fflush(stdin);
        cout<<"Enter the name of the Employee: "<< i <<endl;
        getline(cin,employee[i].name);    
    }
    for (int i=0;i<N;i++){
        fflush(stdin);
        cout<<"Enter the id of the Employee: "<< i <<endl;
        cin>>employee[i].id;       
    }
    for (int i=0;i<N;i++){
        fflush(stdin);
        cout<<"Enter the Salary of the Employee: "<< i <<endl;
        cin>>employee[i].salary;       
    }
    sort(employee, employee+N, compare);
    printf("Employees\n");

    for (int i=0;i<N;i++){

        cout<<employee[i].name<<" "<<employee[i].salary<<" "<<employee[i].id<<endl;
    }
    
    return 0;
}


