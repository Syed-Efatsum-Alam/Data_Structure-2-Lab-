#include<iostream>
using namespace std;
int main() {

    char c;
    while(c!='A'){
        cout<<"Enter a character: "<<endl;
        cin >> c;
        if(c=='A'){
            cout<<"You entered A so the code is Terminatd"<<endl;
            break;
        }
        cout<<"You entered "<<c<<endl;
        
    }
    return 0;
}