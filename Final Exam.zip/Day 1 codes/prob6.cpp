#include<iostream>
using namespace std;
void reverse_array(int arr[],int n){
    int temp;
    for(int i=0;i<n/2;i++){
        temp=arr[i];
        arr[i]=arr[n-i-1];
        arr[n-i-1]=temp;
    }
}
void print_array(int arr[],int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
}
int main() {

    int arr[100],n;
    cout<<"Enter the size of the array: "<<endl;
    cin>>n;
    for (int i = 0; i < n; i++)
    {   
        cout << "Enter the value you want to insert : " << endl;
        cin >> arr[i];
    }
    print_array(arr,n);
    printf("\n");
    printf("The reverse of the array is: ");
    reverse_array(arr,n);
    print_array(arr,n);
    

    return 0;
}