#include<iostream>
using namespace std;
void factorial(int n1){
    int fact1=1;
    int arr[100];
    

    for(int i=1;i<=n1;i++){
        fact1*=i;
       
    } 
    cout<<"The factorial of "<<n1<<" is "<<fact1<<endl;
    
}
 int main() {
        int n1,n2;
        cout<<"Enter the first number: "<<endl;
        cin >> n1;
        cout<<"Enter the second number: "<<endl;
        cin >> n2;
        if (n1>n2){
            for(int i=n2;i<=n1;i++){
                factorial(i);
            }
        }
        if(n2>n1){
            for(int i=n1;i<=n2;i++){
                factorial(i);
            }
        }    
    return 0;
}