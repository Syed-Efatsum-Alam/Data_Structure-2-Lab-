#include<iostream>
//#include <bits/stdc++.h>
using namespace std;
int DPChange(int M, int c[],int d)
{
    int bestNumCoins[M+1],cc[M+1];
    bestNumCoins[0]=0;

    for (int i=1 ; i<=M ; i++)
    {
        bestNumCoins[i]=1000;
        for (int j=0 ; j<d ; j++)
        {
            if(c[j]<=i)
            {
                int x = 1+bestNumCoins[i-c[j]];
                if(x<bestNumCoins[i])
                {
                    bestNumCoins[i]=x;
                    cc[i]=c[j];
                }
            }

        }

    }
    cout<<"Total coin needed "<<bestNumCoins[M]<<"\n";
    cout<<"Coins Are: ";
    int y = M;
    while (y!=0){
       cout<<cc[y]<<"\n";
       y = y-cc[y];
    }
    return bestNumCoins[M];
}



int main()
{
    int M,d;
    cout<<"Enter the number of coins: ";
    cin >> d;
    int c[d];
    for (int i=0; i<d; i++)
    {
        cin >> c[i];
    }
    cout<<"Enter the amount: ";
    cin >> M;
    int x = DPChange(M,c,d);
    cout<<"\nminimum "<<x<<" containers needed.\n";


    return 0;
}
