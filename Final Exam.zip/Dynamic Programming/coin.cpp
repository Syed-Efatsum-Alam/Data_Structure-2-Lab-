#include<iostream>

using namespace std;

int dp[100][100];

int recursiveChange(int M, int coin[],int d){
    if(M==0)
        return 0;
    int bestNumCoins = 100000;
    for (int i=0; i<d; i++){
        if(M>=coin[i]){
            int numCoins = recursiveChange(M-coin[i],coin,d);
            if (numCoins+1 <bestNumCoins){
                bestNumCoins = numCoins+1;
                
            }
            
        }
    }
    return bestNumCoins;
}


int main(){
    int M,d;
    cin >> M >> d;
    int c[d];
    for (int i=0; i<d; i++){
        cin >> c[i];
    }
    int x = recursiveChange(M,c,d);
    cout<<x<<"\n";
    return 0;
}