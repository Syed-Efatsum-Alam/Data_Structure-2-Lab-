#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;


struct club
{
    char c;
    int s_i, d_i;
};


bool comp(club c1, club c2)
{
    int f1 = c1.s_i+c1.d_i;
    int f2 = c2.s_i+c2.d_i;
    return f1 < f2;
}
int act_select(club reqs[], int N, int X){
    sort(reqs, reqs+N, comp);
    int count =1;
    int i=0;
    cout<<reqs[i].c<<" "<<reqs[i].s_i<<" "<<reqs[i].d_i<<endl;
    i++;
    while(i<N){
            if(reqs[i].s_i>=reqs[i-1].s_i+reqs[i].d_i+X){
            cout<<reqs[i].c<<" "<<reqs[i].s_i<<" "<<reqs[i].d_i<<endl;
            count++;
        }
        else{
            return count;
        }
        i++;
    }

}



int main()
{
    int n;
    cout<<"Enter the number of clubs: ";
    cin >> n;
    
    club clubs[n];
    for(int i=0; i<n; i++)
    {
        cin >> clubs[i].c >> clubs[i].s_i >> clubs[i].d_i;
    }
    int X;
    cin>>X;
    printf("\n");
    sort(clubs, clubs+n, comp);
    for(int i=0; i<n; i++)
    {
        cout << clubs[i].c << " " << clubs[i].s_i << " " << clubs[i].d_i << endl;
    }
   printf("\n");
   printf("\n");
   int x=act_select(clubs,n,X);
    cout<<x<<endl;


}
/**
4
a 2 8
b 3 4
d 8 1
c 7 1
0
*/