#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

struct coin{
    int val;
    int quantity;
};

bool comp(coin c1, coin c2){
    return c1.val>c2.val;
}
int coinSelection(coin coins[],int n,int debt){
    sort(coins,coins+n,comp);
    int count=0;
    int i=0;
    int debt_remain=debt;
    while (i<n && debt_remain>0){
        if(debt_remain>coins[i].val){
            coins[i].quantity=debt_remain/coins[i].val;
            debt_remain=debt_remain%coins[i].val;
            // if(coins[i].quantity>0){
            //     cout<<coins[i].val<<" "<<coins[i].quantity<<endl;
            // }
            
            count+=coins[i].quantity;
        }
        else{
            coins[i].quantity=debt_remain/coins[i].val;
            count=count+coins[i].quantity;
            debt_remain=debt_remain%coins[i].val;
            //if(coins[i].quantity>0){
                //cout<<coins[i].val<<" "<<coins[i].quantity<<endl;
            //}
            
        }
         i++;
         }
    return count;
   
    
}
void coinSelectionPrint(coin coins[],int n,int debt){
    sort(coins,coins+n,comp);
    int count=0;
    int i=0;
    int debt_remain=debt;
    while (i<n && debt_remain>0){
        if(debt_remain>coins[i].val){
            coins[i].quantity=debt_remain/coins[i].val;
            debt_remain=debt_remain%coins[i].val;
            if(coins[i].quantity>0){
                cout<<coins[i].val<<" "<<"cents "<<"--- "<<coins[i].quantity<<endl;
            }
        }
        else{
            coins[i].quantity=debt_remain/coins[i].val;
            debt_remain=debt_remain%coins[i].val;
            if(coins[i].quantity>0){
                cout<<coins[i].val<<" "<<"cents "<<"--- "<<coins[i].quantity<<endl;
            }
            
        }
         i++;
         }
    
   
    
}

int main(int argc, char const *argv[])
{
    int n,debt;
    cout<<"Enter the number of coins: ";
    cin>>n;
    coin coins[n];
    cout<<"Enter the value of each coin: ";
    for(int i=0;i<n;i++){
        cin>>coins[i].val;
    }
    
    cout<<"Enter the debt: ";
    cin>>debt;
    cout<<endl;
    coinSelectionPrint(coins,n,debt);
    cout<<"Total "<<coinSelection(coins,n,debt)<<" coins"<<endl;
   

    return 0;
}

