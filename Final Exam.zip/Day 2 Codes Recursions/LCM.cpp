#include<iostream>
using namespace std;
int lcm(int a,int b){
    static int i=1;
    if(i%a==0 && i%b==0){
        return i;
    }
    else{
        i++;
        lcm(a,b);
    }
}
int main(int argc, char const *argv[])
{
    int a,b;
    cout<<"Enter the value of a and b"<<endl;
    cin>>a>>b;
    cout<<lcm(a,b)<<endl;
    return 0;
}