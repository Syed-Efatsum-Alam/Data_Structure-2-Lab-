#include<iostream>
using namespace std;

int Fibonacchi(int n)
{
    if (n==1){
        return 0;
    }
    if (n==2){
        return 1;
    }
    else{
        return Fibonacchi(n-1)+Fibonacchi(n-2);
    }
}
int main()
{
    int n;
    cout << "Enter the value of n" << endl;
    cin>>n;
    int z= Fibonacchi(n);
    cout<<z<<endl;
    return 0;
}
