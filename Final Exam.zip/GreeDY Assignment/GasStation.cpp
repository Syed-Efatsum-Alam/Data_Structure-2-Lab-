#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

struct Gas_Station{
    int distance;
    int number;
};

bool comp(Gas_Station a, Gas_Station b){
    return a.distance<b.distance;
}

void stopage_count(Gas_Station gasDis[],int Total_distance,int Gas_travel_distance,int n){
    sort(gasDis,gasDis+n,comp);
    int i=0;
    int distance_remain=Total_distance;
    int starting_point=0;
    while(i<n&&starting_point<Total_distance){
        if(Gas_travel_distance+starting_point>=Total_distance){
             cout<<"No stop is rquired"<<endl;
             return;
        }
        else if(Gas_travel_distance+starting_point<Total_distance && Gas_travel_distance+starting_point<gasDis[i].distance){
            
            starting_point= gasDis[i-1].distance;
            int x=gasDis[i-1].number;
            cout<<"Stop at "<<x<<"th station"<<"("<<gasDis[i-1].distance<<"km)"<<endl;
        }
        
        i++;
    }
    if(starting_point+Gas_travel_distance<Total_distance){
        cout<<"Not possible to reach"<<endl;
    }

}

int main()
{   
    //n=number of gasstaions.
    int Total_distance,Gas_travel_distance,n;
    cout<<"Enter the total distance: ";
    cin>>Total_distance;
    cout<<"Enter the distance that car can travel with full tank: ";
    cin>>Gas_travel_distance;
    cout<<"Enter the number of total Gas stations: ";
    cin>>n;
    Gas_Station gasDis[n];
    
    for(int i=0;i<n;i++){
        cout<<"Enter the distance of "<<i+1<<"th gas station from the starting point: ";
        cin>>gasDis[i].distance;
        gasDis[i].number=i+1;
    }
    
    stopage_count(gasDis,Total_distance,Gas_travel_distance,n);

    return 0;
}
