#include<iostream>
using namespace std;

int calc_sum(int arr[],int start,int end){
    if(start==end){
        if(arr[start]%2==0){
            return arr[start];
        }
        else{
            return 0;
        }
    }
    else{
        int mid=(start+end)/2;
        int s1=calc_sum(arr,start,mid);
        int s2=calc_sum(arr,mid+1,end);
        return s1+s2;
    }
}
int main(int argc, char const *argv[])
{
    int arr[100],n; 
    cout<<"enter the size of array"<<endl;
    cin>>n;
    cout<<"enter the elements of array"<<endl;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int sum=calc_sum(arr,0,n-1);
    cout<<"the sum of even Elements in the array is "<<sum<<endl;
    return 0;
}