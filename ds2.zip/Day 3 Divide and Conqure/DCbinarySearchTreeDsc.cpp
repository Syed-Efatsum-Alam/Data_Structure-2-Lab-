#include<iostream>
using namespace std;

int binarySearch(int arr[],int start,int end,int key){
    if(start>end){
        return -1;
    }
    else{
        int mid=(start+end)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(arr[mid]<key){
            return binarySearch(arr,start,mid-1,key);
        }
        else{
            return binarySearch(arr,mid+1,end,key);
        }
    }
}
int main(int argc, const char** argv) {

    int arr[100],n,key;
    cout<<"enter the size of array"<<endl;
    cin>>n;
    cout<<"enter the elements of array"<<endl;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"enter the key to be searched"<<endl;
    cin>>key;
    int index=binarySearch(arr,0,n-1,key);
    if(index==-1){
        cout<<"the key is not present in the array"<<endl;
    }
    else{
        cout<<"the key is present at index "<<index<<endl;
    }
    
    return 0;
}