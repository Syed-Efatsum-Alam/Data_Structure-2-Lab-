#include <iostream>
using namespace std;

int countOdd(int a[],int start,int end){
    if(start==end){
        if(a[start]%2!=0){
            return 1;
        }
        else{
            return 0;
        }
    }
    else{
        int mid=(start+end)/2;
        int c1= countOdd(a,start,mid);
        int c2= countOdd(a,mid+1,end);
        return c1+c2;
    }
}
int main()
{
    int arr[100];
    int n;
    cout<<"enter the size of array"<<endl;
    cin>>n;
    cout<<"enter the elements of array"<<endl;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int count=countOdd(arr,0,n-1);
    cout<<"the number of odd elements in the array is "<<count<<endl;
    return 0;
}