#include<iostream>

using namespace std;

int Count_inversion(int arr[],int n,int start,int end){
    if(n==1){
        return 0;
    }
    if (n==2){
        if(arr[start]>arr[end]){
            return 1;
        }
        else{
            return 0;
        }
    }
    else{
        int mid=(start+end)/2;
        int count1=Count_inversion(arr,mid-start+1,start,mid);
        int count2=Count_inversion(arr,end-mid,mid+1,end);
        int count3=0;
        int i=start,j=mid+1;
        while(i<=mid && j<=end){
            if(arr[i]>arr[j]){
                count3++;
                j++;
            }
            else{
                i++;
            }
        }
        return count1+count2+count3;
    }
}
int main()
{
    int arr[]={1 ,20, 6 ,4 ,5 ,8 ,4 ,6 ,2 ,5};   
    int n=sizeof(arr)/sizeof(arr[0]);
    cout<<Count_inversion(arr,n,0,n-1);
   

    return 0;
}
