#include <iostream>
using namespace std;
int k=0;
void SeriesPrint(int arr[],int n){
    
    if(n==0){
        return ;
    }
    else{
        cout<<arr[k]*arr[k]<<"+";
        k++;
        SeriesPrint(arr,n-1);
    }
}
int main(int argc, char const *argv[])
{
    int arr[5]={1,2,3,4,5};
    SeriesPrint(arr,5);
    return 0;
}

