#include<iostream>
using namespace std;

int sumofInt(int n){
    static int sum=0;
    if(n==0){
        return sum;
    }
    else{
        sum=sum+n%10;
        return sumofInt(n/10);
    }
}
int main()
{
    int n;
    cout<<"Enter the number"<<endl;
    cin>>n;
    cout<<sumofInt(n)<<endl;
    return 0;
}