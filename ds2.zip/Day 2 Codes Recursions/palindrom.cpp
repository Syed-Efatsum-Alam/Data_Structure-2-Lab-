#include<iostream>
using namespace std;

bool palindrom(int n){
    static int rev=0;
    static int temp=n;
    if(n==0){
        return temp==rev;
    }
    else{
        rev=rev*10+n%10;
        return palindrom(n/10);
    }
}
int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the number"<<endl;
    cin>>n;
    cout<<palindrom(n)<<endl;
    return 0;
}
