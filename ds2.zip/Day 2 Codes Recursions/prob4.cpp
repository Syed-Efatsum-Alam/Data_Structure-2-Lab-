#include<iostream>

using namespace std;
void conv_to_lower(string& s){
    for(int i=0;i<s.length();i++){
        if(s[i]>='A' && s[i]<='Z'){
            s[i]=s[i]+32;
        }
    }

}

void remove_ws(string& s){
    int i=0;
    while(i<s.length()){
        if(s[i]==' '){
            s.erase(i,1);
        }
        else{
            i++;
        }
    }
}

bool palindrome(string s, int i, int j){
    if(i==j){
        return true;
    }
    if(s[i]!=s[j]){
        return false;
    }
    if(i<j+1){
        return palindrome(s,i+1,j-1);
    }
}

bool isPalindrome(string s){
    int n=s.length();
    if(n==0){
        return true;
    }
    
    
    return palindrome(s,0,n-1);
}

int main()
{
    string s;
    cout << "Enter the String" << endl;
    getline(cin,s);
    cout << s << " is" <<endl;
    remove_ws(s);
    conv_to_lower(s);
    if(isPalindrome(s)){
        cout<<"True"<<endl;
    }
    else{
        cout<<"Flase"<<endl;
    }    
    return 0;
}