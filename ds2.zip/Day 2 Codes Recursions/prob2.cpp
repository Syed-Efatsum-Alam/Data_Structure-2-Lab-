#include<iostream>
using namespace std;
int power(int x, int y)
{
    if(y==0)
        return 1;
    else
        return x*power(x,y-1);
}
int main()
{
    int y,x;
    cout<<"Enter a number: ";
    cin>>x;
    cout<<"Enter the power: ";
    cin>>y;
    cout<<x<<" to the power "<<y<<" is "<<power(x,y);
    return 0;
}
