#include <iostream>

using namespace std;
void printEven (int x,int y){
    if(x<y){
    
        if(x%2==0)
        cout<<x<<endl;
        printEven(x+1,y);
     

    }
    if(x>y){
        if(y%2==0)
        cout<<y<<endl;
        printEven(x,y+1);  
    }
}

int main()
{
    int x,y;
    cout<<"Enter the value of x and y"<<endl;
    cin>>x>>y;
    printEven(x,y);
    return 0;
}