#include<iostream>
using namespace std;

void printSeries(int start1,int start2,int s3,int n){
    if(n==0){
        return ;
    }
    if(n==1){
        cout<<start1<<" * "<<start2<<" * "<<s3<<" + ";
        return ;
    }
    else{
        cout<<start1<<" * "<<start2<<" * "<<s3<<" + ";
        printSeries(start1*2,start2+2,s3-1,n-1);
    }
}
int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the value of n"<<endl;
    cin>>n;
    printSeries(2,3,4,n);
    return 0;
}
