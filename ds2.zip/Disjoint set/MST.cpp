#include<bits/stdc++.h>
using namespace std;

struct Edge{
    int u,v,w;
};

void make_set(int p[], int rank[], int x){
    p[x] = x;
    rank[x] = 0;
}

int find_set(int p[], int x){
    if (x!=p[x])
        p[x] = find_set(p, p[x]);
    return p[x];
}

void _union(int p[], int rank[], int x, int y){
    int a = find_set(p, x);
    int b = find_set(p, y);

    if(rank[a] > rank[b]){
        p[b] = a; 
    }
    else if(rank[a] < rank[b]){
        p[a] = b; 
    }
    else {
        p[a] = b;
        rank[b]++;
    }
    
}

bool cmp(const Edge &e1, const Edge &e2){
    return e1.w < e2.w;
}

vector<Edge> MST(int p[], int rank[], int V, vector<Edge> edges){
    for(int i=0; i<V; i++){
        make_set(p,rank,i);
    }
    
    sort(edges.begin(), edges.end(), cmp);
    
    vector<Edge> mst;
    for(Edge edge : edges){
        if(find_set(p,edge.u)!=find_set(p,edge.v)){
            _union(p,rank,edge.u,edge.v);
            mst.push_back(edge);
        }
    }

    return mst;

}



int main(){


    int N, Edges;
    cout<<"Enter number of vertices and edges: ";
    cin>>N>>Edges;
    int p[N],rank[N];

    vector<Edge> edges;
    for (int i=0;i<Edges;i++){
        Edge e;
        cin>>e.u>>e.v>>e.w;
        edges.push_back(e);
    }

    vector<Edge> mst;
    mst = MST(p,rank,N,edges);

    cout<<"MST\n";
    for(Edge e : mst){
        cout<<e.u<<"-"<<e.v<<endl;
    }
    cout<<"Weight: ";
    int s=0;
    
    for(int i=0; i<mst.size()-1; i++){
        cout<<mst[i].w<<"+";
        s+= mst[i].w;
    }
    cout << mst[mst.size()-1].w<<" = "<<s+mst[mst.size()-1].w<<endl;

    return 0;
}