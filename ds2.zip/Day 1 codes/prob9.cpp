#include<iostream>
#include<algorithm>
using namespace std;

struct Person
{
    string name;
    int height;
    int age;
    
};
bool compareHeight(Person a, Person b)
{
    return a.height > b.height;
}
int main(){
    int N;
    cout<<"Enter the number of persons: "<<endl;
    cin>>N;
    struct Person persons[N];
    for (int i=0;i<N;i++){
        fflush(stdin);
        cout<<"Enter the name of the person: "<<endl;
        getline(cin,persons[i].name);  
        cout<<"Enter the height of the person: "<<endl;
        cin>>persons[i].height;
        cout<<"Enter the age of the person: "<<endl;
        cin>>persons[i].age;
    }

    sort(persons, persons+N, compareHeight);
    printf("Employees\n");
    
    for (int i=0;i<N;i++){

        cout<<persons[i].name<<" "<<persons[i].height<<" "<<"cm"<<" "<<persons[i].age<<endl;
    }
    return 0;
}
