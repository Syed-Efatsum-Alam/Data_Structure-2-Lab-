#include<iostream>
using namespace std;
int main(){

   int n;
   cout<<"Enter the number of elements: "<<endl;
   cin >> n;
   int arr[100];
   for(int i=0;i<n;i++){
       cout<<"Enter the element: "<<endl;
       cin >> arr[i];
   }
   for(int i=0;i<n;i++){
        bool flag=true;
        for(int j=i+1;j<n;j++){
            if(arr[i]>arr[j]){
                flag=false;
                break;
            }
                
        }
        if(flag==true){
            cout<<arr[i]<<" ";
        }
   }


    return 0;
}