#include<iostream> /// c++
using namespace std; /// c++

void print_unique(int A[], int N){

    for (int i=0; i<N; i++){
        /// check if this is
        /// the last occ of A[i]
        bool last = true; /// c++
        for (int j=i+1; j<N; j++){
            if (A[j]==A[i]){
                last = false;
                break;
            }
        }
        if (last) {
            ///printf("%d ",A[i]);
            int _count = 1;
            for (int j=0;j<i;j++){
                if(A[j]==A[i])
                   _count++;
            }
            cout << A[i] << " " << _count << endl;
        }
    }
    ///printf("\n");
    ///cout << "\n";
    cout << endl;

}

int main(){
    int N;
    
    cin >> N;

    int A[N];
    for (int i=0;i<N;i++){
        
        cin >> A[i];
    }

    print_unique(A, N);
}
/**
10
4 4 5 6 5 6 4 5 6 1
*/