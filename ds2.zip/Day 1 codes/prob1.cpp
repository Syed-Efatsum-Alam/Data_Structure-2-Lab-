#include<iostream>

using namespace std;
int main() {

    int n,x;
    int sum;
    cout<<"Enter how many numbers you want to insert: "<<endl;
    cin >> n;
    for(int i=0;i<n;i++){
        cout<<"Enter the number: "<<endl;
        cin >> x;
        sum += x;
    }
    int avg= sum/n;
    cout<<"The average is: "<<avg<<endl;
    cout << avg << endl;

    return 0;
}