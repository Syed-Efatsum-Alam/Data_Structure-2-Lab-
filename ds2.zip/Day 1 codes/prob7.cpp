#include<iostream>
using namespace std;

void conv_to_lower(string& s){
    for(int i=0;i<s.length();i++){
        if(s[i]>='A' && s[i]<='Z'){
            s[i]=s[i]+32;
        }
    }

}
void remove_ws(string& s){
    int i=0;
    while(i<s.length()){
        if(s[i]==' '){
            s.erase(i,1);
        }
        else{
            i++;
        }
    }
}
 int main()
 {
    string s;
    cout << "Enter the String" << endl;
    getline(cin,s);
    conv_to_lower(s);
    remove_ws(s);
    cout << s << endl;

    return 0;
 }
 