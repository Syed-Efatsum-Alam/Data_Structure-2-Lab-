#include<iostream>
using namespace std;

void conv(string& s){
    for(int i=0;i<s.length();i++){
        if(s[i]>='A' && s[i]<='Z'){
            s[i]=s[i]+32;
        }
        else if(s[i]>='a' && s[i]<='z'){
            s[i]=s[i]-32;
        }
    }

}

int main()
 {
    string s;
    cout << "Enter the String" << endl;
    getline(cin,s);
    conv(s);

    cout << s << endl;

    return 0;
 }
 