#include<iostream>
#include <bits/stdc++.h>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the number of slices: ";
    cin>>n;
    int arr[n];
    //cout<<"Enter the price of each slice: ";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int val[n+1];
    val[0] = 0;
    int i, j;
    for(int i=1;i<=n;i++)
    {
        int max_val = INT_MIN;
        for(int j=0;j<i;j++)
        {
            max_val = max(max_val, arr[j] + val[i-j-1]);
        }
        val[i] = max_val;
        // cout<<"Slice "<<i<<" "<<val[i]<<" ";
        // cout<<endl;
    }
    cout<<endl;
    int arr2[100];
    int k=0;
    cout<<"Maximum Obtainable Value is "<<val[n];
    int y,z;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++){
            int x=val[i]+val[j];
            if(x==val[n])
            {
                //cout<<i+1<<" "<<j+1;
                arr2[k]=i;
                k++;
                arr2[k+1]=j;
                
                break;
            }
        }
    }
    cout<<endl;
    for (int i = 0; i < k; i++)
    {
        cout<<arr2[i]<<"togather "<<val[arr2[i]]<<endl;
    }
    


    return 0;
}

