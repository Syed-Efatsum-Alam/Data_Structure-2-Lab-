#include<iostream>
#include<algorithm>
using namespace std;

int profit=0;
struct Zero1Knapsack
{
    int weight;
    int value;
    string name;
};

int comp(Zero1Knapsack a, Zero1Knapsack b)
{
    return a.weight<b.weight;
}
int knapsack (int W, Zero1Knapsack arr[], int n)
{
    if (n==0 || W==0)
        return 0;
    if (arr[n-1].weight > W)
        return knapsack(W, arr, n-1);
    else
        return max(arr[n-1].value + knapsack(W-arr[n-1].weight, arr, n-1), knapsack(W, arr, n-1));
}

int main()
{
    int n;
    cout<<"Enter the number of items: ";
    cin>>n;
    Zero1Knapsack arr[n];

    for(int i=0;i<n;i++)
    {
        cin>>arr[i].name>>arr[i].weight >> arr[i].value;
    }
    int W;
    cin>>W;
    cout<<knapsack(W,arr,n);
    
    return 0;
}