#include<iostream>
#include<algorithm>
using namespace std;

struct ques{
    int marks;
    int time;
    int index;

};

bool comp(ques q1, ques q2){
    return (double)q1.marks/q1.time>(double)q2.marks/q2.time;
}

int frac_Knapsack(ques arr[],int T,int N){
    sort(arr,arr+N,comp);
    int timeleft=T;
    int marks=0;
    int i=0;
    while(timeleft > 0 && i<N){
        if(timeleft>arr[i].time){
            marks=marks+arr[i].marks;
            timeleft=timeleft-arr[i].time;
            cout<<"ques "<<arr[i].index<<" "<<100<<"%"<<" : "<<arr[i].marks<<" marks "<<arr[i].marks<<" marks "<<endl;
        }
        else{
            int x=arr[i].marks*timeleft/arr[i].time;
            double y=(double)x/arr[i].marks;
            marks=marks + x;
            timeleft=0;
            cout<<"ques "<<arr[i].index<<" "<<y*100<<"%"<<" : "<<arr[i].marks<<" marks "<<x<<" marks "<<endl;
        }
        i++;
    }
    return marks;
}




int main(int argc, char const *argv[])
{   
    //n total ques;
    int Total_marks,Total_time,n;
    cout<<"Enter the total marks: ";
    cin>>Total_marks;
    cout<<"Enter the total time: ";
    cin>>Total_time;
    cout<<"Enter the number of questions: ";
    cin>>n;
    ques questions[n];
    for(int i=0;i<n;i++){
        cout<<"Enter the marks and time of question "<<i+1<<": ";
        cin>>questions[i].marks>>questions[i].time;
        questions[i].index=i+1;
    }
    cout<<"The maximum marks is: "<<endl;
    cout<<frac_Knapsack(questions,Total_time,n)<<endl;
 

    return 0;
}
