#include<iostream>
#include<algorithm>
using namespace std;

struct item{
    int weight;
    int value;
    int index;

};

bool comp(item i1, item i2){
    return (double)i1.value/i1.weight>(double)i2.value/i2.weight;
}

int frac_knapsack(int W,item items[],int n){
    sort(items,items+n,comp);
    int capleft=W;
    int profit=0;
    int i=0;
    while(capleft > 0 && i<n){
        if(capleft>items[i].weight){
            profit=profit+items[i].value;
            capleft=capleft-items[i].weight;
            printf("items %d : %d kg %d taka \n",items[i].index,items[i].weight,items[i].value);
        }
        else{
            profit=profit + items[i].value*capleft/items[i].weight;
            capleft=0;
            printf("items %d : %d kg %d taka \n",items[i].index,items[i].weight,items[i].value);
        }
        i++;
    }
    return profit;
}



int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the number of items: ";
    cin>>n;
    item items[n];
    for(int i=0;i<n;i++){
        cout<<"Enter the weight and value of item "<<i+1<<": ";
        cin>>items[i].weight>>items[i].value;
        items[i].index=i+1;
    }
    int W;
    cout<<"Enter the capacity of knapsack: ";
    cin>>W;
    cout<<"The maximum profit is: "<<endl;
    cout<<frac_knapsack(W,items,n)<<endl;

    return 0;
}

/**
4
4 16
3 9
3 18
2 16
5
*/

