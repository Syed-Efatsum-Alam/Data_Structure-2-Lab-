#include <iostream>
#include <algorithm>

using namespace std;

struct jobs{
    int index;
    int start;
    int duration;
    int level;
};

bool comp(jobs j1, jobs j2){
    return j1.start<j2.start;
}

int act_selection(jobs arr[],int n,int Start_time,int End_time,int Money){
    sort(arr,arr+n,comp);
    int salary=0;
    for(int i=0;i<n;i++){
        if(arr[i].start>=Start_time && arr[i].start+arr[i].duration<=End_time){
            salary=salary+Money;
            cout<<"Job "<<arr[i].index<<" Starts at "<<arr[i].start<<", ends at "<<arr[i].start+arr[i].duration<<" and has level "<<arr[i].level<<endl;
            Start_time=arr[i].start+arr[i].duration;
        }
    }
    cout<<"Expected earnings:";
    return salary;
}


int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the number of jobs: ";
    cin>>n;
    jobs job[n];
    for(int i=0;i<n;i++){
        cout<<"Enter the start time, duration and level of job "<<i+1<<": ";
        cin>>job[i].start>>job[i].duration>>job[i].level;
        job[i].index=i+1;
    }
    int Start_time,End_time,Money;
    cout<<"Enter the start time, end time and Expected Salary: ";
    cin>>Money>>Start_time>>End_time;
    cout<<"Recomanded Jobs: "<<endl;   
    cout<<act_selection(job,n,Start_time,End_time,Money)<<endl;

    return 0;
}

