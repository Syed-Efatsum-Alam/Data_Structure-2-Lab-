#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

struct Gas_Station{
    int distance;
    int number;
};

bool comp(Gas_Station a, Gas_Station b){
    return a.distance<b.distance;
}

int stopage_count(Gas_Station gasDis[],int Total_distance,int Gas_travel_distance,int n){
    sort(gasDis,gasDis+n,comp);
    int count=0;
    int i=0;
    int distance_remain=Total_distance;
    while(i<n&&distance_remain>0){
        if(Gas_travel_distance>=distance_remain){
            return count;
        }
        else if(Gas_travel_distance<distance_remain && Gas_travel_distance>=gasDis[i].distance){
            distance_remain=distance_remain-gasDis[i].distance;
            count++;
        }
        else{
            i++;
        }
    }
    return count;
}

int main()
{   
    //n=number of gasstaions.
    int Total_distance,Gas_travel_distance,n;
    Gas_Station gasDis[n];
    cout<<"Enter the number of total Gas stations: ";
    cin>>n;
    
    for(int i=0,j=0;i<n;i++,j++){
        cout<<"Enter the distance of "<<i+1<<"th gas station from the starting point: ";
        cin>>gasDis[i].distance;
    }
    cout<<"Enter the total distance: ";
    cin>>Total_distance;
    cout<<"Enter the distance that car can travel with full tank: ";
    cin>>Gas_travel_distance;
    cout<<"Number of stops: "<<stopage_count(gasDis,Total_distance,Gas_travel_distance,n)<<endl;
    
    

    return 0;
}
