#include<iostream>
#include<algorithm>

using namespace std;

bool comp(double a, double b){
    return a>b;
}

int unit_lenght(double arr[], int n){
    sort(arr, arr+n, comp);
    double lenght=0;
    lenght = arr[0]-arr[n-1];
    cout<<lenght<<endl;
    int count=0;
    int i=0;
    while(i<n && lenght>=0){
        lenght=lenght-1;
        count++;
        i++;
        
    }
    return count;
}

int main(int argc, char const *argv[])
{
    int n;
    cout<<"Enter the number of elements: ";
    cin>>n;
    double arr[n];
    cout<<"Enter values of the set: ";
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    
    cout<<"The maximum number of unit length is: "<<endl;
    cout<<unit_lenght(arr,n)<<endl;
    
    return 0;
}
