#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int n;
struct Item{

    int w,v;
};
bool com(Item i1,Item i2){

    return (double)i1.v/i1.w>(double)i2.v/i2.w;
}

int frac_knapsack(int W,vector<Item>items){
    sort(items.begin(),items.end(),com);
//    for(Item item:items){
//        cout<<item.v<<" "<<item.v<<" "<<(double)item.v/item.w<<endl;
//    }
     /// ... complete yourself
    int capleft=W;
    int profit=0;
    int i=0;
    while(capleft > 0 && i<n){
        if(capleft>items[i].w){
            profit=profit+items[i].v;
            capleft=capleft-items[i].w;
            printf("items %d : %d kg %d taka \n",items[i],items[i].w,items[i].v);
        }
        else{
            profit=profit + items[i].v*capleft/items[i].w;
            capleft=0;
            printf("items %d : %d kg %d taka \n",items[i],items[i].w,items[i].v);
        }
        i++;
    }
    return profit;
}
int main(){
    int W;
    cout<<"Enter the number of items: ";
    cin>>n;
    vector<Item>items;
    for(int i=0;i<n;i++){
        Item item;
        cout<<"Enter the weight and value of item "<<i+1<<": ";
        cin>>item.w>>item.v;
        items.push_back(item);
    }
    cout<<"Enter the capacity of knapsack: ";
    cin>>W;
    int x=frac_knapsack(W,items);
    cout<<x<<endl;
}

/**
4
4 16
3 9
3 18
2 16
5
*/
