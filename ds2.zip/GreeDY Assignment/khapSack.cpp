#include <iostream>
#include <algorithm>
using namespace std;

struct Items
{
    string name;
    double value;
    double weight;
};

bool comp(Items i1, Items i2)
{
    return (double)i1.value / i1.weight > (double)i2.value / i2.weight;
}
bool comp2(Items i1, Items i2)
{
    return i1.weight > i2.weight;
}
double frac_knapsack(int W, Items items[], int n)
{
    sort(items, items + n, comp);
    int capleft = W;
    double profit = 0;
    int i = 0;
    while (capleft > 0 && i < n)
    {   
        if (capleft > items[i].weight)
        {
            profit = profit + items[i].value;
            capleft = capleft - items[i].weight;
            cout << "items " << items[i].name << " : " << items[i].weight << " kg " << items[i].value << " taka " << endl;
            items[i].weight = 0;
            items[i].value = 0;
        }
        else
        {   
            double x=items[i].value * capleft / items[i].weight;
            profit = profit + x; 
            int y= capleft;
            items[i].weight = items[i].weight - capleft;
            items[i].value = items[i].value - x;
            capleft = 0;
            cout << "items " << items[i].name << " : " << y << " kg " << x << " taka " << endl;
        }
        i++;
      
    }
   
    return profit;
}




int main()
{
    int n,k;
    cout<<"Enter the number of items: ";
    cin>>n;
    Items item[n];
    for(int i=0;i<n;i++){
        cout<<"Enter the name, weight and value of item "<<i+1<<": ";
        cin>>item[i].name>>item[i].value>>item[i].weight;
    }
    cout<<"Enter the number of theieves: "<<endl;
    cin>>k;
    int W[k];
    for(int i=0;i<k;i++){
        cout<<"Enter the capacity of theif "<<i+1<<": ";
        cin>>W[i];
    }
    cout<<endl;
    for(int i=0;i<k;i++){
        cout<<"Theif "<<i+1<<" can take: "<<frac_knapsack(W[i],item,n)<<" taka"<<endl;
    }
    cout<<"Total "<<k<<" thieves stole from the Warehouse"<<endl;
    sort(item, item + n, comp2);
    if(item[0].weight!=0){
    cout<<"The remaining items are: "<<endl;
    for(int i=0;i<n;i++){
        if(item[i].weight!=0){
            cout<<item[i].name << " : " << item[i].weight << " kg " << item[i].value << " taka " << endl;
        }
    } 

    }
      
    return 0;
}

